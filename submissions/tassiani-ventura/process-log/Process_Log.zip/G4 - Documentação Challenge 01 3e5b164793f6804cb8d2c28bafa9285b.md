# G4 - Documentação | Challenge 01

# Documentação do processo

<aside>

Esta documentação está organizada em duas camadas: **a cronologia do trabalho**, com prints, prompts e decisões reais, e uma **síntese final**, que organiza os principais aprendizados e intervenções.

</aside>

- Construção do Projeto
    - Escolhi o ChatGPT como principal ambiente de trabalho porque já tinha acesso pago.
    - Antes de enviar as bases, criei o contexto para aproveitar melhor a capacidade técnica da IA.
    - Também criei um prompt-mestre para orientar a investigação.
    - **PRINT**
        
        ![image.png](image.png)
        
    - **Prompt 1 completo**
        
        ![image.png](image%201.png)
        
    - Estruturei esse prompt antes de mostrar os dados para reduzir o risco de a investigação se organizar em torno dos primeiros padrões encontrados.
    
    ![image.png](image%202.png)
    
- Começo | Estrutura
    - Comecei deixando a IA propor uma estrutura inicial para enxergar lacunas que eu poderia não antecipar.
    - **PRINT**
        
        ![image.png](image%203.png)
        
        ![image.png](image%204.png)
        
    - A primeira entrega ficou ampla demais; então mudei a abordagem e passei a direcionar a análise para o que eu precisava visualizar para decidir.
    - **PRINT**
        
        ![image.png](image%205.png)
        
        ![image.png](image%206.png)
        
        ![image.png](image%207.png)
        
        ![image.png](image%208.png)
        
        ![image.png](image%209.png)
        
    - Aprendizado
        
        Ser mais clara sobre **o que eu preciso receber para conseguir decidir e avançar**, mesmo sem formular tecnicamente a análise. Isso evita trabalho desnecessário e reduz carga cognitiva.
        
- Análise 001
    - Esta etapa serviu para entender melhor o que as bases realmente representavam e onde os conceitos ainda estavam ambíguos.
    - **PRINT 1**
        
        ![image.png](image%2010.png)
        
    - Li a entrega e fui questionando, principalmente por áudio no celular, pontos que não faziam sentido de negócio ou exigiam contexto demais.
    - **PRINT 2**
        
        ![image.png](image%2011.png)
        
        - Conversa completa
            
            Resumindo, o que são 3 representações diferentes?
            
            110 como "`accounts`  " significa que sairam em qual momento?
            
            312 "têm alguma subscription  " = algum tipo de produto encerrado? quer dizer que pode ter outro produto ativo?
            
            O que é churn event  ? significa o que??
            
            "têm algum desacordo   " = o que isso significa?
            
            Você tá proibido de usar palavras grávidas comigo.
            
            Eu preciso que você seja mais claro nas respostas, e diga o óbvio também, o que cada coisa siginifica na prática.
            
            - 
                
                ---
                
            
            2
            
            Sobre isso, eu concordo. Por isso a analise importa. A linha reta de uma jornada é uma, Mas o cliente não faz a linha continua. E isso que vamos entender. E entender com efetividade se o Churn subiu, ou se na realidde, podemos olhar por outros ângulos.
            
            - 
                
                ---
                
            
            3
            
            Concordo e eu sei. Mas saiba que eu posso tratar as bases pelos nomes que usei, e vocÊ deve ser capaz de identificar. Se não for, me avise antes.
            
            - ---
            
            4
            
            Imaginei. Então significa que nos dados de Chrun tbm conseguimos medir o tempo que o usuario demorou para se engajar no produto. Seja para criar a conta, e seja para ser cliente. Correto?
            
            `subscriptions.start_date`  é quando ele se torna cliente?
            
            ---
            
            Sobre os tickets antes do signup , eles são antes da "`subscriptions.start_date`" ?
            
            Os tickets tem alguma TAG sobre assunto ou alguma informação? O que podemos extrair deles? Nao ficou muito claro.
            
            O que temos de comparação entre datas? Peridodos para analisar, não apenas de suporte, mas de todas planilhas.
            
            - -------
            
            ---
            
            Duvida: na relação comercial, entendi que existem varios produtos ou condições. Como é isso? Existe padrão?
            
            O que podemos extrair?
            
            - ----
            
            PARTE: O que você ainda não estava vendo
            
            Na parte de origem, acredito que a analise vem depois de outras analises, de churn principalmente. Para depois buscar padrão de origem. Caso voce veja outra coisa, me informe.
            
            O comercial não é linear = sua resposta é vaga. Eu quero saber o que podemos analisar.
            
            - ---
            
            Sobre essas 78 contas, acredito que é um funil que devemos considerar, mesmo que seja no final, quando tivermos mais dados. DEsses 78 quantos chruns tiveram, qual a %, para ai verificar mais conexões e relevancia. è um dado importante que devemos sim levar em consideração.
            
            Inclusive analisar a frequencia que o churn acontece, depois de quantos dia. Faz sentido ?
            
            - ---
            
            Porque devemos construir uma jornada agora? Só foi uma forma de pensar, não quer dizer que faça sentido construir. Quero entender se é realmente a etapa mais coerente "reconstruir os episódios de lifecycle por conta e reconciliar as três manifestações de churn, sem ainda tentar explicar por que ocorreram".
            
            - ---
            
            ME explica isso:
            
            A mediana entre signup e primeira subscription é
            
            **16 dias**
            
            ; para primeira subscription paga,
            
            **19 dias**
            
            .
            
            criou conta → começou alguma subscription (16 dias) → começou uma subscription paga (+4 dia para pagar algo).  é isso? Cria conta. Começa gratis depois de 4 dias, paga?
            
            ---
            
            "O problema é forte: para 490 das 500 contas, o primeiro uso registrado no arquivo ocorre antes do signup. Isso é uma inconsistência do dataset.   "
            
            O que vc acredita que possa ter causadado isso?
            
            ---
            
            Essa questao do suporte é util, ainda mais porque a maioria acontece antes.
            
            ---
            
            Sabemos valores das assinaturas ? é um dado relevante tbm, valor deve aparecer.
            
            ---
            
            Me responde por bullet points. Objetivo e claro.
            
            Precisamos construir uma nova base que conecte esses dados, para que consigamos também analisar de forma mais rápida várias variaveis. Você pode adicionar tudo no Google drive e criar a nova base. Ou outra forma mais pratica.
            
            O ponto é: nao adianta me responder com dados picados. Isso não resolve nada e só faz perder tempo.
            
            Talvez seja melhor migrar para a versão WORK. Antes de construir qualquer coisa, me responda.
            
    - Também pra entender o que a máquina tá interpretando, que só um humano consegue entender ou criar hipoteses melhores.
    - **PRINT 3**
        
        ![image.png](image%2012.png)
        
    - Aprendizado
        
        Acredito que se o relatório tivesse sido feito desde o inicio com python, o processo seria acelerado. 
        
- Análise 002
    - Ajustei as instruções para evitar respostas soltas, exigir pensamento sistêmico e melhorar o formato de entrega dos dados.
    - **PRINT 1**
        
        ![image.png](image%2013.png)
        
    - **PRINT 2**
        
        ![image.png](image%2014.png)
        
    - Aprendizado
        
        Esse alinhamento deveria ter acontecido antes: melhorou tanto a investigação quanto a forma de consumir os resultados. 
        
    
- Análise 003 - Feedback
    - Revisei a análise pensando em uma pessoa não técnica e sem contexto prévio.
    - Usei a leitura e os feedbacks por áudio também para levantar novas conexões que ainda não tinham sido investigadas.
    - **PRINT 1**
        
        ![image.png](image%2015.png)
        
    - **PRINT 2**
        
        ![image.png](image%2016.png)
        
    - **PRINT 3**
        
        ![image.png](image%2017.png)
        
    - **PRINT 4**
        
        ![image.png](image%2018.png)
        
    - **PRINT 5**
        
        ![image.png](image%2019.png)
        
    - **PRINT 6**
        
        ![image.png](image%2020.png)
        
    - **PRINT 7**
        
        ![image.png](image%2021.png)
        
        ![image.png](image%2022.png)
        
- Análise 004 - Teste antes do próximo relátório
    - Antes de gerar outro relatório completo, pedi um teste no chat para validar se a IA tinha entendido os feedbacks. Isso evitou reconstruir um documento inteiro na direção errada.
    - PRINT 1
        
        ![image.png](image%2023.png)
        
    - PRINT 2
        
        ![image.png](image%2024.png)
        
    - PRINT 3
        
        ![image.png](image%2025.png)
        
    - PRINT 4
        
        ![image.png](image%2026.png)
        
- Análise 005 - Relatório estruturado V1
    - Com os dados mais organizados, passei a procurar conexões menos óbvias.
    - **PRINT - entrega**
        
        ![image.png](image%2027.png)
        
        ![image.png](image%2028.png)
        
    - **PRINT 1**
        
        ![image.png](image%2029.png)
        
        ![image.png](image%2030.png)
        
    - Em paralelo à minha leitura, pedi uma visão estratégica para ampliar a investigação e confrontar minhas próprias interpretações.
    - **PRINT 2**
        
        ![image.png](image%2031.png)
        
- Relatório Diagnóstico
    - Abri um novo chat para reduzir o efeito do contexto acumulado e construir um diagnóstico mais independente.
    - A intenção ainda não era fechar a versão final, mas testar outras leituras antes de responder diretamente às perguntas do Challenge.
    - Pedi uma análise que desafiasse a estrutura construída até ali, em vez de apenas reforçá-la.
    - **PRINT 1**
        
        ![image.png](image%2032.png)
        
        ![image.png](image%2033.png)
        
        ![image.png](image%2034.png)
        
    - **PRINT 2**
        
        
        ![image.png](image%2035.png)
        
        ![image.png](image%2036.png)
        
    - Também levei resultados e dados brutos para Claude e Manus, buscando perspectivas diferentes e possíveis contradições.
- Revisão - Aprendizado
    - Revisei as instruções do projeto para consolidar os critérios que passaram a orientar o fechamento: rigor analítico, visão de negócio, clareza e ação.
    - **PRINT**
        
        
        ![image.png](image%2037.png)
        
        ![image.png](image%2038.png)
        
        ![image.png](image%2039.png)
        
        ![image.png](image%2040.png)
        
        - 
            
            Você atua como parceiro **estratégico, analítico, técnico e operacional** no RavenStack Retention Intelligence. Assuma a investigação e a construção das soluções; a decisão estratégica final permanece com a responsável pelo projeto.
            
            Seu objetivo não é apenas explicar churn. É descobrir **o que está acontecendo no negócio, por que está acontecendo, onde estão riscos e oportunidades e quais decisões, processos ou sistemas podem melhorar o resultado econômico da RavenStack**.
            
            Pense primeiro como **gestor e estrategista de negócio** e use dados, estatística e tecnologia como instrumentos para sustentar ou refutar conclusões. Considere de forma integrada aquisição, receita, clientes, produto, comercial, CS, operações e dados sempre que forem relevantes.
            
            Não confirme narrativas existentes nem siga hipóteses por inércia. Procure a explicação mais defensável e esteja disposto a redefinir o próprio problema quando as evidências apontarem outra direção.
            
            Use as cinco bases como fontes primárias. Antes de confiar em qualquer conclusão, valide o que os dados realmente representam: granularidade, chaves, temporalidade, cardinalidade, consistência e significado. Divergências entre documentação e dados são achados, não problemas a esconder.
            
            **Não trate nenhuma lista de análises, segmentos, métricas ou métodos como exaustiva.** Investigue livremente relações, composições, concentrações, mudanças, anomalias, contradições e interações que possam alterar uma decisão — inclusive aquelas que ninguém tenha pedido ou previsto.
            
            Procure especialmente diferenças entre **volume e valor**, crescimento e qualidade do crescimento, movimentação comercial e perda real, médias e composição, correlação e mecanismo. Dinheiro, clientes afetados e relevância para o negócio devem acompanhar os achados desde o início.
            
            Conceitos como churn, cliente ativo, renovação, encerramento, expansão, contração, reativação e receita perdida precisam ser reconciliados antes de serem tratados como verdades.
            
            Separe claramente **fato, cálculo, associação, inferência, hipótese causal e recomendação**. Não apresente associação como causa. Tente refutar suas próprias conclusões e procure explicações alternativas.
            
            Sempre que você puder executar uma investigação com os dados existentes, **execute antes de recomendar que alguém a faça**.
            
            Todo insight material deve ser reproduzível e auditável, mas a complexidade técnica deve permanecer nos bastidores. A comunicação principal deve permitir que uma pessoa não técnica compreenda:
            
            **o que aconteceu → quanto representa → por que importa → o que provavelmente explica → o que ainda não sabemos → o que fazer.**
            
            Recomendações devem resultar em decisão ou ação concreta. Sistemas e aplicações devem ser desenhados para quem realmente os utilizará, priorizando **simplicidade, contexto, inteligência e ação**, e não quantidade de funcionalidades ou gráficos.
            
            Como os dados são sintéticos, diferencie padrões encontrados neste dataset de conclusões sobre clientes SaaS reais.
            
            Antes de qualquer grande entrega, faça uma última revisão perguntando:
            
            > **O que estou deixando de enxergar porque as instruções, as perguntas iniciais ou a estrutura dos dados me levaram a olhar para o problema de uma forma específica?**
            > 
            
            E depois:
            
            > **Que descoberta, conexão ou oportunidade não óbvia poderia mudar a estratégia da RavenStack se eu a encontrasse?**
            > 
            
            O padrão de qualidade é: **pensamento crítico e sistêmico, visão de negócio, criatividade investigativa, rigor analítico, impacto econômico, descobertas não óbvias e soluções executáveis.**
            
            O objetivo não é seguir um framework. É **entender o negócio melhor do que ele é entendido hoje e transformar esse entendimento em melhores decisões.**
            
- Revisão — churn e desenho da solução
    - **PRINT**
        
        
        ![image.png](image%2041.png)
        
        ![image.png](image%2042.png)
        
        ![image.png](image%2043.png)
        
    - **MANUS - Novas instruções**
        
        
        ![image.png](image%2044.png)
        
        ![image.png](image%2045.png)
        
        ![image.png](image%2046.png)
        
    - Proposta **Customer Value & Revenue Intelligence**
        
        # **Customer Value & Revenue Intelligence**
        
        Ela acompanharia toda a base e conectaria:
        
        1. **O que aconteceu com a conta e com a receita.**
        2. **Qual foi a trajetória de valor da conta e onde surgiu o risco.**
        
        ## **Como funcionaria**
        
        ### **Camada 1 — Jornada completa do cliente**
        
        Para cada conta, o sistema mostraria:
        
        - aquisição;
        - venda;
        - promessa comercial;
        - onboarding;
        - primeiro valor;
        - uso recorrente;
        - suporte;
        - expansão ou contração;
        - eventos registrados;
        - renovação, pausa ou saída;
        - situação atual.
        
        Essa camada cobriria **100% da base**, mesmo quando alguns campos estiverem ausentes.
        
        ### **Camada 2 — Verdade econômica**
        
        O sistema reconciliaria:
        
        - eventos;
        - assinaturas;
        - contratos;
        - invoices;
        - pagamentos;
        - MRR antes e depois;
        - mudanças de plano;
        - reembolsos;
        - perda ou manutenção da relação comercial.
        
        Assim, ele separaria:
        
        - evento registrado;
        - churn de cliente;
        - contração;
        - migração;
        - reativação;
        - revenue churn;
        - evento sem perda comprovada.
        
        ### **Camada 3 — Inteligência e risco**
        
        Com os dados anteriores, o sistema poderia identificar:
        
        - segmentos com maior concentração de problemas;
        - contas específicas que merecem investigação;
        - trajetórias comuns entre contas que saíram;
        - sinais que antecederam perda real;
        - contas com risco econômico;
        - contas apenas com dados incompletos;
        - contas que precisam de intervenção de CS.
        
        O modelo preditivo entraria aqui, mas como **um componente da plataforma**, não como o produto inteiro.
        
        ### **Camada 4 — Operação**
        
        Para cada conta prioritária, o time teria:
        
        - motivo da priorização;
        - evidências utilizadas;
        - hipótese de problema;
        - responsável;
        - prazo;
        - próxima ação;
        - status;
        - histórico;
        - resultado da intervenção.
        
        Assim, a plataforma não apenas “aponta risco”. Ela ajuda o time a agir e registrar se a ação funcionou.
        
        ## **O que muda em relação às duas propostas separadas?**
        
        As propostas originais virariam dois motores dentro de um mesmo sistema:
        
        | **Motor** | **Função** |
        | --- | --- |
        | **Revenue Truth** | Descobrir se houve perda econômica real |
        | **Customer Value Journey** | Entender o caminho da conta e onde o valor foi perdido ou não entregue |
        
        Eles precisam estar juntos porque cada um corrige a limitação do outro.
        
        ### **Sem a camada econômica**
        
        Você pode identificar uma jornada ruim, mas não saber se ela causou perda real de receita.
        
        ### **Sem a jornada do cliente**
        
        Você pode saber que houve perda financeira, mas não entender o que levou a ela.
        
        ### **Com os dois integrados**
        
        Você consegue responder:
        
        **Qual foi a trajetória que levou à perda, em quais segmentos isso acontece, quanto dinheiro representa e qual ação deve ser tomada?**
        
        ## **O sistema deve olhar toda a base?**
        
        Sim.
        
        A arquitetura ideal seria:
        
        - **100% das contas no mapa de jornada;**
        - **100% das contas com estado econômico conhecido ou marcado como desconhecido;**
        - **100% das contas com nível de completude dos dados;**
        - **priorização operacional apenas para as contas que precisam de ação imediata.**
        
        Isso evita confundir “não está na fila” com “não apresenta risco”.
        
        Uma conta pode estar:
        
        - saudável;
        - em observação;
        - com risco operacional;
        - com risco econômico;
        - com evento não reconciliado;
        - sem dados suficientes;
        - em intervenção;
        - resolvida;
        - perdida.
        
        ## **Como ele responderia às duas perguntas do projeto?**
        
        ### **1. O que está causando o churn?**
        
        O sistema compararia as jornadas de:
        
        - contas que permaneceram;
        - contas que expandiram;
        - contas que contraíram;
        - contas que realmente saíram;
        - contas com evento, mas sem perda econômica.
        
        Depois, cruzaria aquisição, plano, uso, suporte, onboarding, promessa comercial e contrato para identificar padrões que diferenciam os grupos.
        
        ### **2. Quais segmentos estão mais em risco?**
        
        O sistema analisaria cada segmento por:
        
        - número de contas afetadas;
        - percentual de contas afetadas;
        - MRR perdido;
        - revenue churn;
        - tempo até primeiro valor;
        - problemas de onboarding;
        - qualidade da aquisição;
        - completude dos dados;
        - sinais atuais de risco.
        
        Também exibiria as **contas específicas** dentro de cada segmento, com a evidência que justificou a priorização.
        
        ## **A única ressalva importante**
        
        Seria uma única plataforma, mas não necessariamente um único modelo ou uma única métrica.
        
        Ela deveria manter separados:
        
        - **evento**;
        - **churn de logo**;
        - **revenue churn**;
        - **risco operacional**;
        - **risco econômico**;
        - **qualidade ou ausência de dados**.
        
        O erro seria criar um “score geral” que mistura tudo. A solução correta é ter **um sistema integrado com conceitos separados e rastreáveis**.
        
        A formulação final seria:
        
        **Construiremos uma única plataforma de inteligência de valor do cliente e receita, cobrindo toda a base, com um motor de reconciliação econômica, um motor de jornada e valor, inteligência de risco e operação de CS integrada.**
        
        Esse é um produto muito mais forte do que dois dashboards independentes: ele conecta **causa, impacto financeiro, segmento, conta específica e ação** em um mesmo fluxo.
        
    - Para o relatório refiz perguntas especificas em chats separados, pra direcionar as novas conexões e melhorias. E depois finalizei num único chat.
    - **PRINTS**
        
        
        ![image.png](image%2047.png)
        
        ![image.png](image%2048.png)
        
        ![image.png](image%2049.png)
        
        ![image.png](image%2050.png)
        
- **Customer Value & Revenue Intelligence (dados atuais)**
    - Decidi materializar a proposta visualmente para complementar o relatório e testar como a lógica funcionaria em uso.
    - Manus (free)
        - **PRINT**
            
            
            ![image.png](image%2051.png)
            
            ![image.png](image%2052.png)
            
        - Chegamos num modelo base
    - GPT
        - Usei o Manus até o limite disponível e continuei a evolução no GPT.
        - PRINT 1
            
            ![image.png](image%2053.png)
            
        - PRINT 2
            
            ![image.png](image%2054.png)
            
        - A otimização ficou incompleta nesta etapa e foi retomada nas fases seguintes, já com o GPT/Work e a evolução da aplicação.
- **Jornada do Cliente (novo sistema)**
    - A proposta foi evoluir o sistema existente para um fluxo centrado na jornada do cliente.
    - Mantive a estrutura técnica já construída para concentrar esforço na lógica e na experiência, evitando retrabalho sem impacto no resultado.
    - **PRINT**
        
        ![image.png](image%2055.png)
        
    - Construí a evolução com o GPT Work e aprendi a usar o Streamlit para colocar a aplicação no ar.
- **Consolidação e reconstrução do relatório final**
    - Depois de organizar e aprovar a narrativa do relatório, usei a IA para revisar estrutura, clareza e requisitos técnicos da entrega.
    - Em seguida, preparei a solução oficial com relatório, aplicação, código, outputs reproduzíveis e estrutura de submissão.

---

# Síntese final do processo

<aside>
🧭

Esta página tem duas camadas: **a cronologia**, com prints, prompts e decisões reais do processo; e **esta síntese**, que organiza o que mudou, onde a IA errou, como eu intervim e como a solução final foi construída.

</aside>

## 1. Como o projeto evoluiu

O trabalho começou como um diagnóstico de churn. O cruzamento das cinco bases mostrou que havia um problema anterior: **os registros associados a churn não representavam, de forma consistente, uma perda definitiva de cliente ou receita**.

A investigação então evoluiu em quatro movimentos:

1. **Entender os dados** — estrutura, chaves, granularidade, temporalidade e significado dos campos.
2. **Investigar o negócio** — aquisição, receita, produto, suporte, segmentos e qualidade do crescimento.
3. **Testar e refutar interpretações** — voltar aos dados sempre que uma explicação parecia boa demais ou dependia de uma premissa não comprovada.
4. **Transformar descoberta em solução** — construir um relatório executivo e uma aplicação que permitisse continuar investigando e agir.

<aside>

**A principal mudança de raciocínio foi esta:** parei de tratar “churn” como um campo pronto para ser explicado e passei a tratá-lo como um conceito que precisava ser reconciliado antes de qualquer decisão.

</aside>

## 2. Como decompus o problema

| Etapa | Pergunta principal |
| --- | --- |
| Dados | O que cada base realmente representa e quais relações são confiáveis? |
| Definição | O que significa churn neste dataset e quais sinais não podem ser tratados como equivalentes? |
| Diagnóstico | O que mudou entre 2023 e 2024 quando aquisição, valor, produto, suporte e eventos são analisados juntos? |
| Validação | As conclusões permanecem quando mudam os recortes, denominadores e janelas temporais? |
| Impacto e decisão | Quanto isso representa, quais contas merecem atenção e o que é possível recomendar com segurança? |
| Produto e comunicação | Como transformar a investigação em uma solução que um gestor consiga entender e usar? |

A decomposição mudou durante o projeto. Quando percebia que a pergunta feita à IA não era a melhor pergunta para o negócio, eu voltava uma etapa e reformulava a investigação.

## 3. Ferramentas utilizadas

| Ferramenta | Uso no projeto |
| --- | --- |
| **ChatGPT / ChatGPT Work** | Principal ambiente de investigação, análise, programação, construção dos relatórios, desenvolvimento e testes da aplicação. |
| **Manus e Claude** | Segunda perspectiva para revisar resultados, testar outras leituras e explorar alternativas de estrutura e produto. |
| **Python** | Execução e validação reproduzível dos cálculos e cruzamentos. |
| **Streamlit** | Transformação da lógica analítica em uma aplicação navegável. |
| **Notion** | Registro do processo, prints, decisões, aprendizados e mudanças de direção. |

## 4. Onde a IA errou — e como corrigi

| Problema | Minha intervenção | Efeito |
| --- | --- | --- |
| Respostas fragmentadas por tabela ou métrica. | Pedi uma leitura sistêmica do negócio. | A análise passou a conectar aquisição, receita, produto, suporte e churn. |
| Churn flag, churn event e subscription encerrada apareciam como equivalentes. | Questionei o significado de cada representação. | A definição de churn passou a ser tratada como problema a resolver, não como premissa. |
| A IA recomendava análises que ela mesma poderia executar. | Criei a regra: se os dados permitem investigar, investigue antes de recomendar. | As recomendações passaram a vir depois da evidência. |
| Associações começaram a ser narradas como causa. | Exigi separação entre fato, cálculo, associação, inferência e hipótese causal. | Produto, suporte, canal e reason codes deixaram de receber causalidade que os dados não sustentavam. |
| Refund apareceu inicialmente como perda econômica. | Pedi cruzamentos com pagamento, subscriptions, temporalidade e continuidade da conta. | O campo passou a ser tratado como refund/crédito registrado, não automaticamente como receita ou cliente perdidos. |
| Os primeiros sistemas e relatórios tinham informação demais ou exigiam contexto prévio. | Usei minha própria dificuldade de leitura como teste de UX e recomecei quando necessário. | A entrega final ficou mais simples, contextual e orientada à decisão. |

## 5. O que eu acrescentei além da IA

Meu papel ficou concentrado onde a automação sozinha não resolvia:

- redefinir o problema quando os dados contradiziam a pergunta inicial;
- decidir quais relações tinham relevância de negócio e mereciam aprofundamento;
- exigir contexto econômico junto aos números;
- impedir que lacunas fossem preenchidas com hipóteses apresentadas como fatos;
- transformar recomendações genéricas em decisões com responsável, ação e objetivo;
- avaliar clareza, carga cognitiva e utilidade real da solução;
- manter comigo a decisão estratégica final, usando a IA como capacidade de investigação, cálculo, construção e contraponto.

## 6. Descobertas que mudaram o rumo do projeto

**1. O churn não era um conceito resolvido.** Diferentes sinais associados a churn não contavam a mesma história. Isso mudou a ordem da investigação.

**2. Evento registrado não era sinônimo de perda.** Os cruzamentos mostraram eventos enquanto ainda existia relação paga e, em alguns casos, antes mesmo do primeiro pagamento.

**3. O crescimento mudou a leitura dos segmentos.** Organic apareceu ao mesmo tempo como área com muitos eventos e como um dos principais motores de crescimento. A pergunta deixou de ser “qual segmento churna mais?” e passou a incluir **qual crescimento gera valor que permanece**.

**4. Refund não resolveu sozinho o impacto econômico.** O campo inclui crédito/refund e aparece em contas que continuam comercialmente ativas.

**5. O problema final ficou mais preciso.** As bases registram vários movimentos da relação com o cliente, mas não oferecem uma sequência econômica única que permita converter automaticamente esses movimentos em perda real de cliente ou receita.

## 7. Do diagnóstico para a solução

O diagnóstico mostrou que um dashboard de churn ou um score único de risco simplificaria demais o problema.

A solução evoluiu para uma plataforma de **Customer Value & Revenue Intelligence**, combinando dois motores:

- **Revenue Truth:** entender o que aconteceu economicamente com a conta.
- **Customer Value Journey:** entender a trajetória da conta e onde surgiram valor, risco ou fricção.

Juntos, eles conectam **trajetória, impacto econômico, segmento, conta específica e ação**.

## 8. UX e validação final

Na evolução da aplicação, percebi fadiga visual e decisória ao usar o próprio sistema. Isso mudou o critério de design: menos informação competindo pela atenção e mais clareza sobre **o que aconteceu, por que importa e qual é a próxima ação**.

Antes de fechar a entrega, revisei relatório e sistema pelas perspectivas de CEO, Financeiro, Comercial/Growth, CS, Produto, Dados/BI, UX e gestor não técnico.

O teste final foi simples:

> **Uma pessoa que não acompanhou o projeto consegue entender o que aconteceu, quanto representa, por que importa, o que sabemos, o que ainda não sabemos e o que fazer?**
> 

## 9. Iterações

A documentação atual registra **13 macroetapas cronológicas**, cada uma com múltiplas interações, testes e correções.

Não contei prompts individuais porque isso distorceria o processo. As mudanças relevantes aconteceram em ciclos de **leitura → crítica → novo cálculo → validação → reconstrução**.

## 10. Resultado

A entrega final reúne:

- **diagnóstico executivo**, com a narrativa e as decisões;
- **análise reproduzível**, para verificar os principais números;
- **aplicação**, para continuar a investigação no nível de conta e jornada;
- **documentação do processo**, mostrando como IA e julgamento humano foram combinados.

<aside>
💡

**Principal aprendizado:** o maior ganho da IA não foi responder mais rápido. Foi permitir testar mais perguntas, refutar conclusões aparentemente boas e executar investigações que eu não conseguiria explorar manualmente no mesmo tempo.

</aside>