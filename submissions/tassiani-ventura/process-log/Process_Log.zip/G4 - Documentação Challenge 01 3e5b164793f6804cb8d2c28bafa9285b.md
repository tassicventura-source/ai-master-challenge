# G4 - Documentação | Challenge 01

# Documentação do processo

<aside>

Esta documentação está organizada em duas camadas: **a cronologia do trabalho**, com prints, prompts e decisões reais, e uma **síntese final**, que organiza os principais aprendizados e intervenções.

</aside>

- Construção do Projeto
    - Escolhi o ChatGPT como principal ambiente de trabalho porque já tinha acesso pago.
    - Antes de enviar as bases, criei o contexto para aproveitar melhor a capacidade técnica da IA.
    - Também criei um prompt-mestre para orientar a investigação.
    - **PRINT**
        
        ![image.png](image.png)
        
    - **Prompt 1 completo**
        
        ![image.png](image%201.png)
        
    - Estruturei esse prompt antes de mostrar os dados para reduzir o risco de a investigação se organizar em torno dos primeiros padrões encontrados.
    
    ![image.png](image%202.png)
    
- Começo | Estrutura
    - Comecei deixando a IA propor uma estrutura inicial para enxergar lacunas que eu poderia não antecipar.
    - **PRINT**
        
        ![image.png](image%203.png)
        
        ![image.png](image%204.png)
        
    - A primeira entrega ficou ampla demais; então mudei a abordagem e passei a direcionar a análise para o que eu precisava visualizar para decidir.
    - **PRINT**
        
        ![image.png](image%205.png)
        
        ![image.png](image%206.png)
        
        ![image.png](image%207.png)
        
        ![image.png](image%208.png)
        
        ![image.png](image%209.png)
        
    - Aprendizado
        
        Ser mais clara sobre **o que eu preciso receber para conseguir decidir e avançar**, mesmo sem formular tecnicamente a análise. Isso evita trabalho desnecessário e reduz carga cognitiva.
        
- Análise 001
    - Esta etapa serviu para entender melhor o que as bases realmente representavam e onde os conceitos ainda estavam ambíguos.
    - **PRINT 1**
        
        ![image.png](image%2010.png)
        
    - Li a entrega e fui questionando, principalmente por áudio no celular, pontos que não faziam sentido de negócio ou exigiam contexto demais.
    - **PRINT 2**
        
        ![image.png](image%2011.png)
        
        - Conversa completa
            
            Resumindo, o que são 3 representações diferentes?
            
            110 como "`accounts`  " significa que sairam em qual momento?
            
            312 "têm alguma subscription  " = algum tipo de produto encerrado? quer dizer que pode ter outro produto ativo?
            
            O que é churn event  ? significa o que??
            
            "têm algum desacordo   " = o que isso significa?
            
            Você tá proibido de usar palavras grávidas comigo.
            
            Eu preciso que você seja mais claro nas respostas, e diga o óbvio também, o que cada coisa siginifica na prática.
            
            - 
                
                ---
                
            
            2
            
            Sobre isso, eu concordo. Por isso a analise importa. A linha reta de uma jornada é uma, Mas o cliente não faz a linha continua. E isso que vamos entender. E entender com efetividade se o Churn subiu, ou se na realidde, podemos olhar por outros ângulos.
            
            - 
                
                ---
                
            
            3
            
            Concordo e eu sei. Mas saiba que eu posso tratar as bases pelos nomes que usei, e vocÊ deve ser capaz de identificar. Se não for, me avise antes.
            
            - ---
            
            4
            
            Imaginei. Então significa que nos dados de Chrun tbm conseguimos medir o tempo que o usuario demorou para se engajar no produto. Seja para criar a conta, e seja para ser cliente. Correto?
            
            `subscriptions.start_date`  é quando ele se torna cliente?
            
            ---
            
            Sobre os tickets antes do signup , eles são antes da "`subscriptions.start_date`" ?
            
            Os tickets tem alguma TAG sobre assunto ou alguma informação? O que podemos extrair deles? Nao ficou muito claro.
            
            O que temos de comparação entre datas? Peridodos para analisar, não apenas de suporte, mas de todas planilhas.
            
            - -------
            
            ---
            
            Duvida: na relação comercial, entendi que existem varios produtos ou condições. Como é isso? Existe padrão?
            
            O que podemos extrair?
            
            - ----
            
            PARTE: O que você ainda não estava vendo
            
            Na parte de origem, acredito que a analise vem depois de outras analises, de churn principalmente. Para depois buscar padrão de origem. Caso voce veja outra coisa, me informe.
            
            O comercial não é linear = sua resposta é vaga. Eu quero saber o que podemos analisar.
            
            - ---
            
            Sobre essas 78 contas, acredito que é um funil que devemos considerar, mesmo que seja no final, quando tivermos mais dados. DEsses 78 quantos chruns tiveram, qual a %, para ai verificar mais conexões e relevancia. è um dado importante que devemos sim levar em consideração.
            
            Inclusive analisar a frequencia que o churn acontece, depois de quantos dia. Faz sentido ?
            
            - ---
            
            Porque devemos construir uma jornada agora? Só foi uma forma de pensar, não quer dizer que faça sentido construir. Quero entender se é realmente a etapa mais coerente "reconstruir os episódios de lifecycle por conta e reconciliar as três manifestações de churn, sem ainda tentar explicar por que ocorreram".
            
            - ---
            
            ME explica isso:
            
            A mediana entre signup e primeira subscription é
            
            **16 dias**
            
            ; para primeira subscription paga,
            
            **19 dias**
            
            .
            
            criou conta → começou alguma subscription (16 dias) → começou uma subscription paga (+4 dia para pagar algo).  é isso? Cria conta. Começa gratis depois de 4 dias, paga?
            
            ---
            
            "O problema é forte: para 490 das 500 contas, o primeiro uso registrado no arquivo ocorre antes do signup. Isso é uma inconsistência do dataset.   "
            
            O que vc acredita que possa ter causadado isso?
            
            ---
            
            Essa questao do suporte é util, ainda mais porque a maioria acontece antes.
            
            ---
            
            Sabemos valores das assinaturas ? é um dado relevante tbm, valor deve aparecer.
            
            ---
            
            Me responde por bullet points. Objetivo e claro.
            
            Precisamos construir uma nova base que conecte esses dados, para que consigamos também analisar de forma mais rápida várias variaveis. Você pode adicionar tudo no Google drive e criar a nova base. Ou outra forma mais pratica.
            
            O ponto é: nao adianta me responder com dados picados. Isso não resolve nada e só faz perder tempo.
            
            Talvez seja melhor migrar para a versão WORK. Antes de construir qualquer coisa, me responda.
            
    - Também pra entender o que a máquina tá interpretando, que só um humano consegue entender ou criar hipoteses melhores.
    - **PRINT 3**
        
        ![image.png](image%2012.png)
        
    - Aprendizado
        
        Acredito que se o relatório tivesse sido feito desde o inicio com python, o processo seria acelerado. 
        
- Análise 002
    - Ajustei as instruções para evitar respostas soltas, exigir pensamento sistêmico e melhorar o formato de entrega dos dados.
    - **PRINT 1**
        
        ![image.png](image%2013.png)
        
    - **PRINT 2**
        
        ![image.png](image%2014.png)
        
    - Aprendizado
        
        Esse alinhamento deveria ter acontecido antes: melhorou tanto a investigação quanto a forma de consumir os resultados. 
        
    
- Análise 003 - Feedback
    - Revisei a análise pensando em uma pessoa não técnica e sem contexto prévio.
    - Usei a leitura e os feedbacks por áudio também para levantar novas conexões que ainda não tinham sido investigadas.
    - **PRINT 1**
        
        ![image.png](image%2015.png)
        
    - **PRINT 2**
        
        ![image.png](image%2016.png)
        
    - **PRINT 3**
        
        ![image.png](image%2017.png)
        
    - **PRINT 4**
        
        ![image.png](image%2018.png)
        
    - **PRINT 5**
        
        ![image.png](image%2019.png)
        
    - **PRINT 6**
        
        ![image.png](image%2020.png)
        
    - **PRINT 7**
        
        ![image.png](image%2021.png)
        
        ![image.png](image%2022.png)
        
- Análise 004 - Teste antes do próximo relátório
    - Antes de gerar outro relatório completo, pedi um teste no chat para validar se a IA tinha entendido os feedbacks. Isso evitou reconstruir um documento inteiro na direção errada.
    - PRINT 1
        
        ![image.png](image%2023.png)
        
    - PRINT 2
        
        ![image.png](image%2024.png)
        
    - PRINT 3
        
        ![image.png](image%2025.png)
        
    - PRINT 4
        
        ![image.png](image%2026.png)
        
- Análise 005 - Relatório estruturado V1
    - Com os dados mais organizados, passei a procurar conexões menos óbvias.
    - **PRINT - entrega**
        
        ![image.png](image%2027.png)
        
        ![image.png](image%2028.png)
        
    - **PRINT 1**
        
        ![image.png](image%2029.png)
        
        ![image.png](image%2030.png)
        
    - Em paralelo à minha leitura, pedi uma visão estratégica para ampliar a investigação e confrontar minhas próprias interpretações.
    - **PRINT 2**
        
        ![image.png](image%2031.png)
        
- Relatório Diagnóstico
    - Abri um novo chat para reduzir o efeito do contexto acumulado e construir um diagnóstico mais independente.
    - A intenção ainda não era fechar a versão final, mas testar outras leituras antes de responder diretamente às perguntas do Challenge.
    - Pedi uma análise que desafiasse a estrutura construída até ali, em vez de apenas reforçá-la.
    - **PRINT 1**
        
        ![image.png](image%2032.png)
        
        ![image.png](image%2033.png)
        
        ![image.png](image%2034.png)
        
    - **PRINT 2**
        
        
        ![image.png](image%2035.png)
        
        ![image.png](image%2036.png)
        
    - Também levei resultados e dados brutos para Claude e Manus, buscando perspectivas diferentes e possíveis contradições.
- Revisão - Aprendizado
    - Revisei as instruções do projeto para consolidar os critérios que passaram a orientar o fechamento: rigor analítico, visão de negócio, clareza e ação.
    - **PRINT**
        
        
        ![image.png](image%2037.png)
        
        ![image.png](image%2038.png)
        
        ![image.png](image%2039.png)
        
        ![image.png](image%2040.png)
        
        - 
            
            Você atua como parceiro **estratégico, analítico, técnico e operacional** no RavenStack Retention Intelligence. Assuma a investigação e a construção das soluções; a decisão estratégica final permanece com a responsável pelo projeto.
            
            Seu objetivo não é apenas explicar churn. É descobrir **o que está acontecendo no negócio, por que está acontecendo, onde estão riscos e oportunidades e quais decisões, processos ou sistemas podem melhorar o resultado econômico da RavenStack**.
            
            Pense primeiro como **gestor e estrategista de negócio** e use dados, estatística e tecnologia como instrumentos para sustentar ou refutar conclusões. Considere de forma integrada aquisição, receita, clientes, produto, comercial, CS, operações e dados sempre que forem relevantes.
            
            Não confirme narrativas existentes nem siga hipóteses por inércia. Procure a explicação mais defensável e esteja disposto a redefinir o próprio problema quando as evidências apontarem outra direção.
            
            Use as cinco bases como fontes primárias. Antes de confiar em qualquer conclusão, valide o que os dados realmente representam: granularidade, chaves, temporalidade, cardinalidade, consistência e significado. Divergências entre documentação e dados são achados, não problemas a esconder.
            
            **Não trate nenhuma lista de análises, segmentos, métricas ou métodos como exaustiva.** Investigue livremente relações, composições, concentrações, mudanças, anomalias, contradições e interações que possam alterar uma decisão — inclusive aquelas que ninguém tenha pedido ou previsto.
            
            Procure especialmente diferenças entre **volume e valor**, crescimento e qualidade do crescimento, movimentação comercial e perda real, médias e composição, correlação e mecanismo. Dinheiro, clientes afetados e relevância para o negócio devem acompanhar os achados desde o início.
            
            Conceitos como churn, cliente ativo, renovação, encerramento, expansão, contração, reativação e receita perdida precisam ser reconciliados antes de serem tratados como verdades.
            
            Separe claramente **fato, cálculo, associação, inferência, hipótese causal e recomendação**. Não apresente associação como causa. Tente refutar suas próprias conclusões e procure explicações alternativas.
            
            Sempre que você puder executar uma investigação com os dados existentes, **execute antes de recomendar que alguém a faça**.
            
            Todo insight material deve ser reproduzível e auditável, mas a complexidade técnica deve permanecer nos bastidores. A comunicação principal deve permitir que uma pessoa não técnica compreenda:
            
            **o que aconteceu → quanto representa → por que importa → o que provavelmente explica → o que ainda não sabemos → o que fazer.**
            
            Recomendações devem resultar em decisão ou ação concreta. Sistemas e aplicações devem ser desenhados para quem realmente os utilizará, priorizando **simplicidade, contexto, inteligência e ação**, e não quantidade de funcionalidades ou gráficos.
            
            Como os dados são sintéticos, diferencie padrões encontrados neste dataset de conclusões sobre clientes SaaS reais.
            
            Antes de qualquer grande entrega, faça uma última revisão perguntando:
            
            > **O que estou deixando de enxergar porque as instruções, as perguntas iniciais ou a estrutura dos dados me levaram a olhar para o problema de uma forma específica?**
            > 
            
            E depois:
            
            > **Que descoberta, conexão ou oportunidade não óbvia poderia mudar a estratégia da RavenStack se eu a encontrasse?**
            > 
            
            O padrão de qualidade é: **pensamento crítico e sistêmico, visão de negócio, criatividade investigativa, rigor analítico, impacto econômico, descobertas não óbvias e soluções executáveis.**
            
            O objetivo não é seguir um framework. É **entender o negócio melhor do que ele é entendido hoje e transformar esse entendimento em melhores decisões.**
            
- Revisão — churn e desenho da solução
    - **PRINT**
        
        
        ![image.png](image%2041.png)
        
        ![image.png](image%2042.png)
        
        ![image.png](image%2043.png)
        
    - **MANUS - Novas instruções**
        
        
        ![image.png](image%2044.png)
        
        ![image.png](image%2045.png)
        
        ![image.png](image%2046.png)
        
    - Proposta **Customer Value & Revenue Intelligence**
        
        # **Customer Value & Revenue Intelligence**
        
        Ela acompanharia toda a base e conectaria:
        
        1. **O que aconteceu com a conta e com a receita.**
        2. **Qual foi a trajetória de valor da conta e onde surgiu o risco.**
        
        ## **Como funcionaria**
        
        ### **Camada 1 — Jornada completa do cliente**
        
        Para cada conta, o sistema mostraria:
        
        - aquisição;
        - venda;
        - promessa comercial;
        - onboarding;
        - primeiro valor;
        - uso recorrente;
        - suporte;
        - expansão ou contração;
        - eventos registrados;
        - renovação, pausa ou saída;
        - situação atual.
        
        Essa camada cobriria **100% da base**, mesmo quando alguns campos estiverem ausentes.
        
        ### **Camada 2 — Verdade econômica**
        
        O sistema reconciliaria:
        
        - eventos;
        - assinaturas;
        - contratos;
        - invoices;
        - pagamentos;
        - MRR antes e depois;
        - mudanças de plano;
        - reembolsos;
        - perda ou manutenção da relação comercial.
        
        Assim, ele separaria:
        
        - evento registrado;
        - churn de cliente;
        - contração;
        - migração;
        - reativação;
        - revenue churn;
        - evento sem perda comprovada.
        
        ### **Camada 3 — Inteligência e risco**
        
        Com os dados anteriores, o sistema poderia identificar:
        
        - segmentos com maior concentração de problemas;
        - contas específicas que merecem investigação;
        - trajetórias comuns entre contas que saíram;
        - sinais que antecederam perda real;
        - contas com risco econômico;
        - contas apenas com dados incompletos;
        - contas que precisam de intervenção de CS.
        
        O modelo preditivo entraria aqui, mas como **um componente da plataforma**, não como o produto inteiro.
        
        ### **Camada 4 — Operação**
        
        Para cada conta prioritária, o time teria:
        
        - motivo da priorização;
        - evidências utilizadas;
        - hipótese de problema;
        - responsável;
        - prazo;
        - próxima ação;
        - status;
        - histórico;
        - resultado da intervenção.
        
        Assim, a plataforma não apenas “aponta risco”. Ela ajuda o time a agir e registrar se a ação funcionou.
        
        ## **O que muda em relação às duas propostas separadas?**
        
        As propostas originais virariam dois motores dentro de um mesmo sistema:
        
        | **Motor** | **Função** |
        | --- | --- |
        | **Revenue Truth** | Descobrir se houve perda econômica real |
        | **Customer Value Journey** | Entender o caminho da conta e onde o valor foi perdido ou não entregue |
        
        Eles precisam estar juntos porque cada um corrige a limitação do outro.
        
        ### **Sem a camada econômica**
        
        Você pode identificar uma jornada ruim, mas não saber se ela causou perda real de receita.
        
        ### **Sem a jornada do cliente**
        
        Você pode saber que houve perda financeira, mas não entender o que levou a ela.
        
        ### **Com os dois integrados**
        
        Você consegue responder:
        
        **Qual foi a trajetória que levou à perda, em quais segmentos isso acontece, quanto dinheiro representa e qual ação deve ser tomada?**
        
        ## **O sistema deve olhar toda a base?**
        
        Sim.
        
        A arquitetura ideal seria:
        
        - **100% das contas no mapa de jornada;**
        - **100% das contas com estado econômico conhecido ou marcado como desconhecido;**
        - **100% das contas com nível de completude dos dados;**
        - **priorização operacional apenas para as contas que precisam de ação imediata.**
        
        Isso evita confundir “não está na fila” com “não apresenta risco”.
        
        Uma conta pode estar:
        
        - saudável;
        - em observação;
        - com risco operacional;
        - com risco econômico;
        - com evento não reconciliado;
        - sem dados suficientes;
        - em intervenção;
        - resolvida;
        - perdida.
        
        ## **Como ele responderia às duas perguntas do projeto?**
        
        ### **1. O que está causando o churn?**
        
        O sistema compararia as jornadas de:
        
        - contas que permaneceram;
        - contas que expandiram;
        - contas que contraíram;
        - contas que realmente saíram;
        - contas com evento, mas sem perda econômica.
        
        Depois, cruzaria aquisição, plano, uso, suporte, onboarding, promessa comercial e contrato para identificar padrões que diferenciam os grupos.
        
        ### **2. Quais segmentos estão mais em risco?**
        
        O sistema analisaria cada segmento por:
        
        - número de contas afetadas;
        - percentual de contas afetadas;
        - MRR perdido;
        - revenue churn;
        - tempo até primeiro valor;
        - problemas de onboarding;
        - qualidade da aquisição;
        - completude dos dados;
        - sinais atuais de risco.
        
        Também exibiria as **contas específicas** dentro de cada segmento, com a evidência que justificou a priorização.
        
        ## **A única ressalva importante**
        
        Seria uma única plataforma, mas não necessariamente um único modelo ou uma única métrica.
        
        Ela deveria manter separados:
        
        - **evento**;
        - **churn de logo**;
        - **revenue churn**;
        - **risco operacional**;
        - **risco econômico**;
        - **qualidade ou ausência de dados**.
        
        O erro seria criar um “score geral” que mistura tudo. A solução correta é ter **um sistema integrado com conceitos separados e rastreáveis**.
        
        A formulação final seria:
        
        **Construiremos uma única plataforma de inteligência de valor do cliente e receita, cobrindo toda a base, com um motor de reconciliação econômica, um motor de jornada e valor, inteligência de risco e operação de CS integrada.**
        
        Esse é um produto muito mais forte do que dois dashboards independentes: ele conecta **causa, impacto financeiro, segmento, conta específica e ação** em um mesmo fluxo.
        
    - Para o relatório refiz perguntas especificas em chats separados, pra direcionar as novas conexões e melhorias. E depois finalizei num único chat.
    - **PRINTS**
        
        
        ![image.png](image%2047.png)
        
        ![image.png](image%2048.png)
        
        ![image.png](image%2049.png)
        
        ![image.png](image%2050.png)
        
- Customer Value & Revenue Intelligence (dados atuais)
    - Decidi materializar a proposta visualmente para complementar o relatório e testar como a lógica funcionaria em uso. Esse protótipo corresponde ao material **Customer Value & Revenue Intelligence (dados atuais)** e antecede o novo sistema de Jornada do Cliente. Após o fechamento do diagnóstico, revisei o HTML para que ele permanecesse totalmente alinhado ao **Relatório Final**, sem tratar `churn_event`, `churn_flag`, refund/crédito ou valores de subscription como perda econômica comprovada.
    - Manus (free)
        - **PRINT**
            
            
            ![image.png](image%2051.png)
            
            ![image.png](image%2052.png)
            
        - Chegamos num modelo base
    - GPT
        - Usei o Manus até o limite disponível e continuei a evolução no GPT.
        - PRINT 1
            
            ![image.png](image%2053.png)
            
        - PRINT 2
            
            ![image.png](image%2054.png)
            
        - A otimização ficou incompleta nesta etapa e foi retomada nas fases seguintes, já com o GPT/Work e a evolução da aplicação.
- Jornada do Cliente (novo sistema)
    - A proposta foi evoluir o sistema existente para um fluxo centrado na jornada do cliente.
    - Mantive a estrutura técnica já construída para concentrar esforço na lógica e na experiência, evitando retrabalho sem impacto no resultado.
    - **PRINT**
        
        ![image.png](image%2055.png)
        
    - Construí a evolução com o GPT Work e aprendi a usar o Streamlit para colocar a aplicação no ar.
- Consolidação e reconstrução do relatório final
    - Depois de organizar e aprovar a narrativa do relatório, usei a IA para revisar estrutura, clareza e requisitos técnicos da entrega.
    - Em seguida, preparei a solução oficial com relatório, aplicação, código, outputs reproduzíveis e estrutura de submissão.
- Reconstrução no Manus e publicação da versão reestruturada
    - Na etapa final de desenvolvimento, migrei a reconstrução do aplicativo para o Manus. O motivo foi operacional: neste projeto, considerei suas entregas de programação mais assertivas e o ChatGPT Work começou a interromper o fluxo com limite de uso excedido com frequência.
    - Levei para o Manus o diagnóstico já construído, as cinco bases e o desenho do sistema que eu queria transformar em uma aplicação de uso diário. A reconstrução passou a priorizar fluxo operacional — conta, interação, próxima ação, responsável, prazo, acompanhamento e resultado — em vez de apenas acrescentar telas ao diagnóstico.
    - Trabalhei em duas contas do Manus para conseguir continuar a implementação quando os créditos de uma delas terminavam. Isso foi uma solução de continuidade do desenvolvimento, não uma etapa metodológica diferente nem uma tentativa de aumentar artificialmente o número de ferramentas usadas.
    - As iterações finais concentraram-se em tornar o MVP funcional no Streamlit, reduzir fadiga visual e decisória, preservar os limites analíticos do diagnóstico, registrar mudanças feitas pelos usuários e preparar a estrutura para GitHub e deploy. Onde a persistência externa não estava configurada, mantive a limitação explícita em vez de apresentar o armazenamento local como solução definitiva.
    - A versão reestruturada foi consolidada com código, documentação de uso, briefing para o CEO, treinamento dos funcionários, testes e instruções de deploy. O diagnóstico continuou sendo a fonte oficial das conclusões; a aplicação ficou como complemento operacional para transformar evidência em acompanhamento e ação.
    - Na validação registrada dessa versão, passaram 87 testes automatizados: 54 de regras, persistência local e dados; 33 de interface com Streamlit AppTest. A inicialização também foi conferida em um clone limpo. Isso verifica o escopo dos testes executados; não significa certificação de produção ou validação de todas as condições de uso.
    - Aprendizado: definir com mais clareza o brieging e construir um Blueprint para validação.
- Documento de Impacto x Ações
    - **PRINT**
        
        
        ![Ajustar entrega G4 - Google Chrome.jpg](Ajustar_entrega_G4_-_Google_Chrome.jpg)
        
        ![image.png](image%2056.png)
        
        ![image.png](image%2057.png)
        
        ![image.png](image%2058.png)
        
- Revisão final de toda documentação
    - A revisão final no Github foi feita com auxilio do GPT. Ele acabou intermediando os ajustes nas documentações finais nos documentos. Revisei a partir dos documentos prontos.

---

# Síntese final do processo

<aside>

Esta síntese organiza os principais movimentos do projeto. A cronologia acima preserva os prints, prompts e decisões reais.

</aside>

## 1. Como trabalhei

O projeto começou como um diagnóstico de churn, mas a primeira decisão importante foi **não assumir que churn já estava corretamente definido nas bases**.

O processo seguiu ciclos de **pergunta → cruzamento dos dados → teste → crítica → novo cálculo → decisão**. Sempre que uma interpretação dependia de uma premissa não comprovada, eu voltava aos dados.

A investigação atravessou as cinco bases e conectou aquisição, receita, subscriptions, produto e suporte. A regra central passou a ser: **se os dados permitem investigar, investigar antes de recomendar**.

## 2. Ferramentas e papel de cada uma

| Ferramenta | Papel no projeto |
| --- | --- |
| **ChatGPT / ChatGPT Work** | Principal ambiente de investigação, análise, contraponto, programação inicial, relatórios e revisão final. |
| **Manus** | Reconstrução da versão mais recente do aplicativo, principalmente programação, UX, persistência e preparação para GitHub/Streamlit. Migrei essa etapa porque o Work atingia limites de uso rapidamente e, neste projeto, o Manus estava entregando programação mais assertiva. Usei duas contas apenas para manter continuidade quando os créditos terminavam. |
| **Claude** | Segunda perspectiva para confrontar interpretações e resultados. |
| **Python** | Cálculos, cruzamentos, testes e reprodução analítica. |
| **Streamlit** | Aplicação operacional. |
| **Notion** | Registro da cronologia, prints, decisões e aprendizados. |

## 3. Onde a IA errou — e como intervim

| Problema | Minha intervenção | O que mudou |
| --- | --- | --- |
| A análise começou fragmentada por tabela e métrica. | Pedi leitura sistêmica do negócio. | Aquisição, receita, produto, suporte e churn passaram a ser analisados em conjunto. |
| `churn_flag`, `churn_event` e subscription encerrada apareciam como equivalentes. | Questionei o significado e cruzei as representações. | Churn deixou de ser premissa e virou parte do problema investigado. |
| A IA recomendava análises que ela mesma poderia executar. | Determinei que toda investigação possível fosse executada antes da recomendação. | Recomendações passaram a vir depois da evidência. |
| Associações começaram a ser narradas como causa. | Exigi separação entre fato, cálculo, associação, inferência e hipótese causal. | Produto, Suporte, canais e `reason_code` deixaram de receber causalidade não sustentada. |
| Refund apareceu inicialmente como perda econômica. | Pedi cruzamentos com subscriptions, temporalidade e continuidade paga. | Refund/crédito deixou de ser tratado automaticamente como receita ou cliente perdido. |
| Relatórios e primeiras versões do sistema geravam carga cognitiva alta. | Usei minha própria dificuldade de leitura e navegação como teste de UX. | A solução foi simplificada e reorganizada em torno de contexto, decisão e próxima ação. |

## 4. Decisões que mudaram o projeto

- **Churn não era um conceito resolvido.** Eventos registrados, flags e encerramentos de linhas não contavam a mesma história. Isso mudou a ordem da investigação.
- **Evento registrado não era sinônimo de perda.** A análise encontrou eventos durante relações pagas, antes do primeiro pagamento e associados a outros movimentos de ciclo de vida. O foco passou a ser reconciliar o desfecho econômico real.
- **Crescimento e risco precisavam ser lidos juntos.** Organic concentrava eventos, mas também grande parte do crescimento de contas e valor. Em vez de concluir que “Organic causa churn”, aprofundei suas composições e a qualidade do crescimento.
- **A priorização não poderia depender apenas de materialidade.** Questionei a primeira proposta de colocar automaticamente as 92 contas como P0. As ações foram reorganizadas por área, evidência, impacto, urgência/risco, esforço e dependências, permitindo frentes paralelas.
- **O plano precisava corrigir o futuro, não apenas investigar o passado.** A estratégia final passou a trabalhar simultaneamente em três frentes: investigar o histórico, interromper novas ambiguidades e melhorar o registro da jornada daqui para frente.
- Um exemplo foi Suporte: a hipótese de que tickets anteriores à assinatura fossem pré-venda não se sustentava automaticamente, porque **1.077 dos 2.000 tickets aparecem antes do próprio signup**. Em vez de forçar uma interpretação, a recomendação passou a ser registrar etapa da jornada, motivo, solução, pendência e próximo passo nos novos atendimentos.

## 5. Como a solução foi construída e validada

A entrega final combina quatro peças com funções diferentes:

- **Relatório executivo:** comunica o que aconteceu, quanto representa, por que importa e o que fazer.
- **Reprodução analítica:** registra perguntas, cálculos, testes, hipóteses refutadas e rastreabilidade.
- **Plano de ação:** organiza ações por área e horizonte, conectando investigação, correção do processo e evolução futura.
- **Customer Journey:** aplicação complementar para transformar sinais em contexto, decisão, ação, responsável, acompanhamento e resultado.

O aplicativo não trata evento histórico como churn econômico automático. Ele foi desenhado para preservar incerteza, registrar decisões humanas e melhorar a qualidade da informação produzida durante a jornada.

A versão final passou por **87 testes automatizados** e por teste manual da aplicação publicada. A documentação técnica mantém explícitas as limitações reais do MVP, inclusive persistência e ausência de autenticação corporativa.

## 6. O que eu acrescentei — e principal aprendizado

Meu papel foi principalmente **questionar o enquadramento**, decidir quais perguntas tinham relevância de negócio, exigir contexto econômico, impedir que hipóteses virassem fatos e transformar análises em decisões executáveis.

A IA ampliou minha capacidade de investigar, calcular, programar e testar alternativas, mas a decisão estratégica permaneceu humana.